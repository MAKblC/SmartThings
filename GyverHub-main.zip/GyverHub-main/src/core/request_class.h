#pragma once

namespace gh {
class Request;
}